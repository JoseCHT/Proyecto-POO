/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectopoo;
import java.util.*;
/**
 *
 * @author Gerardo Ch
 */
public class Prestamos {
    /*
    Varaible         Tipo        Uso
    nombre           Personas    Almacena el nombre de las personas.
    fecha            Date        Almacena la fecha de prestamo del libro.
    libro            Libro       Almacena el nombre del libro prestado.

    
    */
    private Personas nombres;
    private Calendar fecha = Calendar.getInstance();
    private Libro libro;
    private boolean disponible=true;
    
    public void put_nombres (Personas in_nombre)    
    {
        this.nombres = in_nombre;
    }
    
    public void put_libro (Libro in_libro)
    {
        this.libro = in_libro;
    }
    
    public void put_fecha (int in_dia, int in_mes, int in_anio)
    {
        this.fecha.set(in_dia, in_mes, in_anio);
    }

        public void put_disponible(boolean in_disponible)
    {
        this.disponible = in_disponible;
    }
    
    public Libro get_libro()
    {
        return this.libro;
    }
    
    public Calendar get_fecha()
    {
        return this.fecha;
    }
    
    public Personas get_nombres()
    {
        return this.nombres;
    }
    
    public boolean get_disponible()
    {
        return this.disponible;
    }
}
