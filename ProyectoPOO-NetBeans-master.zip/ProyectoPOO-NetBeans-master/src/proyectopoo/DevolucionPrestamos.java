/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectopoo;
import javax.swing.*;
import java.awt.*;
import java.util.*;
/**
 *
 * @author Gerardo Ch
 */
public class DevolucionPrestamos extends JFrame{
    public DevolucionPrestamos()
    {
        /*
        Variable        Tipo            Uso
        btnDevolver     JButton         Es el boton que termina la funcion 
                                        una vez seleccionados las personsa y libros.
        btnRegresar     JButton         Botón que cancela la acción y devuelve el 
                                        menú principal. 
        p1              JPanel          Es uno de los contenedores de los elementos.
        p2              JPanel          Es uno de los contenedores de los elementos.
        
        */
        super("Proyecto 1.0");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(this.EXIT_ON_CLOSE);
        
        JPanel p1 = new JPanel(new GridLayout(0,2));
        JPanel p2 = new JPanel(new GridLayout (1,4));
        JPanel p3 = new JPanel ();
        
        JButton btnDevolver = new JButton("Devolver");
        JButton btnRegresar = new JButton ("Regresar");
        
        String nombresPersonas[] = new String [ProyectoPOO.prestamos.length];
        String nombresLibros[] = new String [ProyectoPOO.prestamos.length];       
      
        
        String dia [] = new String [31];
        String mes [] = {"Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"};;
        String anio [] = new String [621];
        
        for(int i=0;i<ProyectoPOO.prestamos.length;i++ )
            nombresPersonas[i]=ProyectoPOO.personas[i].get_nombre();
        
        for(int i=0;i<ProyectoPOO.prestamos.length;i++)
            nombresLibros[i] = ProyectoPOO.libros[i].get_titulo();
    
        for(int i=0;i<dia.length;i++)
            dia[i]=Integer.toString(i+1);
            
        for(int i=0;i<anio.length;i++)
            anio[i]=Integer.toString(2020-i);
        
        JLabel lbTitulo = new JLabel ("Libro");
        JComboBox cbTitulo = new JComboBox (nombresLibros);
        JLabel lbNombre = new JLabel ("Nombre");
        JComboBox cbNombre = new JComboBox(nombresPersonas);
        JComboBox cbDia = new JComboBox(dia);
        JComboBox cbMes = new JComboBox(mes);
        JComboBox cbAnio = new JComboBox(anio);


        btnDevolver.addActionListener(new java.awt.event.ActionListener(){
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBorrarActionPerformed(cbTitulo.getSelectedIndex(),cbDia.getSelectedIndex()+1, cbMes.getSelectedIndex(), 2020-cbAnio.getSelectedIndex());
            }
        });
        
        btnRegresar.addActionListener(new java.awt.event.ActionListener(){
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegresarActionPerformed(evt);
            }
        });
        
        p1.add(lbTitulo);
        p1.add(cbTitulo);
        p1.add(lbNombre);
        p1.add(cbNombre);
        
        p2.add(cbDia);
        p2.add(cbMes);
        p2.add(cbAnio);
        
        p3.add(btnRegresar);
        p3.add(btnDevolver);   
        
        add(p1, BorderLayout.NORTH);
        add(p2, BorderLayout.CENTER);
        add(p3, BorderLayout.SOUTH);
        
        pack();
        setVisible(true);
    }
    private void btnBorrarActionPerformed(int i_nombre,int dia, int mes, int anio)
    {
 
        
           for(int i=0;i<ProyectoPOO.prestamos.length;i++)
           {
            if(i_nombre == i)
            {
                ProyectoPOO.prestamos[i].put_nombres(new Personas());
                ProyectoPOO.prestamos[i].put_libro(new Libro());
                
            }
           
         }
       
  
        new ProyectoPOO();
        this.setVisible(false);

    }
        private void btnRegresarActionPerformed(java.awt.event.ActionEvent evt)
    {        
        new ProyectoPOO();
        this.setVisible(false);
    }
}
