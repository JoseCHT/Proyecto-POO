/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectopoo;
import javax.swing.*;
import java.awt.*;
import java.util.*;

/**
 *
 * @author Gerardo Ch
 */
public class RegistroPrestamos extends JFrame{
    public RegistroPrestamos()
    {
        /*
        Varaible            Tipo            Uso         
        btnAgregar       JButton        Es el boton que termina la funcion y 
                                        agregar lo que este seleccionado del JComboBox.
                                        una vez seleccionados las personsa y libros.
        btnRegresar     JButton         Botón que cancela la acción y devuelve el 
                                        menú principal. 
        p1              JPanel          Es uno de los contenedores de los elementos.
        p2              JPanel          Es uno de los contenedores de los elementos.
        */
        super("Proyecto 1.0");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(this.EXIT_ON_CLOSE);
        
        JPanel p1 = new JPanel (new GridLayout (0,2));
        JPanel p2 = new JPanel (new GridLayout (1,4));
        JPanel p3 = new JPanel ();
        
        JButton btnAgregar = new JButton("Agregar");
        JButton btnRegresar = new JButton ("Regresar");
        
        String nombresPersonas[] = new String [ProyectoPOO.personas.length];
        String nombresLibros[] = new String [ProyectoPOO.libros.length];
        
        String dia [] = new String [31];
        String mes [] = {"Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"};;
        String anio [] = new String [621];
        
        for(int i=0;i<ProyectoPOO.personas.length;i++ )
            nombresPersonas[i]=ProyectoPOO.personas[i].get_nombre();
        
        for(int i=0;i<ProyectoPOO.libros.length;i++)
            nombresLibros[i] = ProyectoPOO.libros[i].get_titulo();
    
        for(int i=0;i<dia.length;i++)
            dia[i]=Integer.toString(i+1);
            
        for(int i=0;i<anio.length;i++)
            anio[i]=Integer.toString(2020-i);
        
        JLabel lbTitulo = new JLabel ("Libro");
        JComboBox cbTitulo = new JComboBox (nombresLibros);
        JLabel lbNombre = new JLabel ("Nombre");
        JComboBox cbNombre = new JComboBox(nombresPersonas);
        JComboBox cbDia = new JComboBox(dia);
        JComboBox cbMes = new JComboBox(mes);
        JComboBox cbAnio = new JComboBox(anio);        
       
        btnAgregar.addActionListener(new java.awt.event.ActionListener(){
            public void actionPerformed(java.awt.event.ActionEvent evt) {
              btnAgregarActionPerformed(cbTitulo.getSelectedIndex(),cbNombre.getSelectedIndex(), cbDia.getSelectedIndex()+1, cbMes.getSelectedIndex(), 2020-cbAnio.getSelectedIndex());
            }
        });
                
        btnRegresar.addActionListener(new java.awt.event.ActionListener(){
          public void actionPerformed(java.awt.event.ActionEvent evt) {
               btnRegresarActionPerformed();
            }
       });       
        
        p1.add(lbTitulo);
        p1.add(cbTitulo);
        p1.add(lbNombre);
        p1.add(cbNombre);
        
        p2.add(cbDia);
        p2.add(cbMes);
        p2.add(cbAnio);
        
        p3.add(btnRegresar);
        p3.add(btnAgregar);
        
        add(p1, BorderLayout.NORTH);
        add(p2, BorderLayout.CENTER);
        add(p3, BorderLayout.SOUTH);
        
        pack();
        setVisible(true);
    }
    private void btnAgregarActionPerformed(int dia, int mes, int anio, int i_libro, int i_nombre)
    {
      try
      {
        int i=0;
        boolean confirmar = false;
        while(confirmar)
        { 
            if(ProyectoPOO.prestamos[i].get_disponible())
            {
            ProyectoPOO.prestamos[i].put_nombres(ProyectoPOO.personas[i_nombre]);
            ProyectoPOO.prestamos[i].put_libro (ProyectoPOO.libros[i_libro]);
            ProyectoPOO.prestamos[i].put_fecha(dia,mes,anio);
            ProyectoPOO.prestamos[i].put_disponible(false);
            confirmar = false;
            }
            else
            {
                i++;
            }
            
        }
        
      }
              catch(ArrayIndexOutOfBoundsException e)
        {
            JOptionPane.showMessageDialog(this, "Todos los espacios estan "+
                    "llenos.\nSi desea agregar otro autor debe de borrar algun"
                    + "o.");
        }
      
        new ProyectoPOO();
        this.setVisible(false);
    }
    
    private void btnRegresarActionPerformed()
    {
        new ProyectoPOO();
        this.setVisible(false);
    }

    }   

